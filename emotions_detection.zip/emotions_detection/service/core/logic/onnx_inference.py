import onnxruntime as rt
import numpy as np
import cv2


def emotions_detector(image_array):
    providers = ['CPUExecutionProvider']
    m_q= rt.InferenceSession("eff_quantized.onnx", providers= providers)

    test_image = cv2.resize(test_image, (256,256))
    # Convert the image to numpy
    im = np.float32(test_image)
    # print(im.shape) # but this needs to be 4 dimensional
    #adding batch dimension so shape is [1, height, width, channels])
    im_array = np.expand_dims(im, axis=0)
    print(im_array.shape)

    #make predictions with onnx
    onnx_pred = m_q.run(['dense'],{"input":im_array})
    print(np.argmax(onnx_pred[0][0]))
    
    emotion = ""
    if np.argmax(onnx_pred[0][0])== 0:
        emotion = "angry"
    elif np.argmax(onnx_pred[0][0]) == 1:
        emotion = "happy"
    else:
        emotion = "sad"
    return {"emotion":emotion}