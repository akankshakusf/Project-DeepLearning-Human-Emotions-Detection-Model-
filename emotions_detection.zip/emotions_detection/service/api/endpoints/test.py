from fastapi import APIRouter,UploadFile, HTTPException
from PIL import Image #for images
from io import BytesIO  #to read image 
import numpy as np 

#Make an object 
test_router = APIRouter()

#use object as decorator for get 
@test_router.pget("/test")  #entrypoint
def testing():

    
    return {"testing" : "testing"}
