from fastapi import APIRouter,UploadFile, HTTPException
from PIL import Image #for images
from io import BytesIO  #to read image 
import numpy as np 
from service.core.logic.onnx_inference import emotions_detector

#Make an object 
emo_router = APIRouter()

#use object as decorator for get 
@emo_router.post("/detect")  #entrypoint
def detect(im:UploadFile):

    #check if the updoaded file is an image 
    if im.filename.split(".")[-1] in ("jpg","png","jpeg"):
        pass
    else:
        raise HTTPException(
            status_code=415, details="Not an image"
        )

    #open uploaded image 
    image = Image.open(BytesIO(im.file.read()))

    #convert image to numpy 
    image = np.array(image)

    return emotions_detector(image)
